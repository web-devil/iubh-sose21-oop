class StartGameController implements IController {
    public void execute() {
        System.out.println("Spiel starten");
        System.out.println("=============");
    }
}