interface IPlayerManagement {
    public Player getPlayer1();
    public Player getPlayer2();
    public void onExit();
}