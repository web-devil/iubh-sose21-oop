class ShowScoreboardController implements IController {
    public void execute() {
        System.out.println("Scoreboard");
        System.out.println("==========");
    }
}