import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RenamePlayerController renamePlayer = new RenamePlayerController(scanner);
        IPlayerManagement playerManagement = new FilePlayerManagement();
        Menu menu = new Menu(scanner, playerManagement, renamePlayer);

        menu.printAndSelect();
    }
}