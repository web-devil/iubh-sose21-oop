interface IController {
    // Interfaces geben Methodensignaturen vor aber KEINE IMplementierung
    // z.B. public String getName();
}